﻿public interface IInjectable
{

}