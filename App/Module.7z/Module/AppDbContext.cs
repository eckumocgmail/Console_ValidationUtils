﻿using Areas.Admin.Data.Entities;

using Auth;
using Auth.Data;

using Data;

using DataCommon;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

using MvcDeliveryAuth.Domains.Medical;

using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;


/// <summary>
/// Контекст базы данных EF
/// </summary>
public class AppDbContext : MedicalDbContext, IAuthDbContext
{
    public virtual DbSet<News> News { get; set; }
    public virtual DbSet<UserRole> UserRoles { get; set; }
    public virtual DbSet<Service> Services { get; set; }
    public virtual DbSet<Role> Roles { get; set; }
    public virtual DbSet<Account> Accounts { get; set; }
    public virtual DbSet<Person> Persons { get; set; }
    public virtual DbSet<User> Users { get; set; }
    public virtual DbSet<Login> Logins { get; set; }
    public virtual DbSet<Message> Messages { get; set; }

    public AppDbContext() : base()
    {
    }
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }
}
namespace Data
{
    


}
public class AppDbInitiallizer
{
    private static void CreateNews(AppDbContext db)
    {
        db.News.Add(new Areas.Admin.Data.Entities.News()
        {
            Title = "Новая версия",
            Text = "Новая версия рсширяет функционал системы.",
            Href = "/"
        });
        db.News.Add(new Areas.Admin.Data.Entities.News()
        {
            Title = "Новая версия",
            Text = "Новая версия рсширяет функционал системы.",
            Href = "/"
        });
        db.News.Add(new Areas.Admin.Data.Entities.News()
        {
            Title = "Новая версия",
            Text = "Новая версия рсширяет функционал системы.",
            Href = "/"
        });
        db.News.Add(new Areas.Admin.Data.Entities.News()
        {
            Title = "Новая версия",
            Text = "Новая версия рсширяет функционал системы.",
            Href = "/"
        });
        db.News.Add(new Areas.Admin.Data.Entities.News()
        {
            Title = "Новая версия",
            Text = "Новая версия рсширяет функционал системы.",
            Href = "/"
        });
        db.News.Add(new Areas.Admin.Data.Entities.News()
        {
            Title = "Новая версия",
            Text = "Новая версия рсширяет функционал системы.",
            Href = "/"
        });
        db.SaveChanges();
    }

    private static void CreateRole(AppDbContext db)
    {
        db.Roles.Add(new Auth.Data.Role("User"));
        db.SaveChanges();
    }

    internal static void Init(AppDbContext db)
    {
        AppDbInitiallizer.CreateRole(db);
        AppDbInitiallizer.CreateUser(db);
        AppDbInitiallizer.CreateServices(db);
        AppDbInitiallizer.CreateNews(db);
    }



    private static void CreateServices(AppDbContext db)
    {
        if (db.Services.Count() == 0)
        {
            db.Services.Add(new Service()
            {
                Code = "Api",
                Name = "API",
                Description = "Предоставляет информацию о API-контроллерах приложения",
            });
        }
        db.SaveChanges();
    }

    private static void CreateUser(AppDbContext db)
    {
        
    }
}