﻿using Areas.Admin.Data.Entities;

using Data;
using Data.RepositoryPattern;

using Microsoft.EntityFrameworkCore;

using System.Collections.Generic;

namespace Data.Services
{


    public interface INewsRepository
    {
        public IEnumerable<News> GetTopRated();        
    }


    public class NewsRepository: EntityRepository<News>, INewsRepository
    {
        public NewsRepository(AppDbContext context) : base(context)
        {
            
        }

        public override DbSet<News> GetDbSet( DbContext context)
            => ((AppDbContext)context).News;

        public IEnumerable<News> GetTopRated()
            => this.Get(null);
    }
}
