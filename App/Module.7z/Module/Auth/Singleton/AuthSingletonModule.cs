﻿ 
using Auth.Singleton.ClientFactory;


using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using UserAuthMVC.Auth.Services;

namespace Auth.Singleton
{
    public class AuthSingletonModule : IServiceModule, IAuthSingletonModule
    {
        private ILogger<AuthSingletonModule> Logger = Factory.GetLogger<AuthSingletonModule>();
        private ClientFactoryModule ClientFactoryModule = new ClientFactoryModule();
        public void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {
            Logger.LogInformation($"ConfigureServices(...)");
            ClientFactoryModule.ConfigureServices(configuration, services);
            services.AddScoped(typeof(UserContext), sp => sp.GetService<IAuthContext>().GetUserContext(sp.GetService<ITokenProvider>().Get()));
            services.AddSingleton(typeof(IAuthOptions), sp =>
            {
                return configuration.GetSection(nameof(IAuthOptions)).Get<AuthOptions>();
            });
            services.AddSingleton<IAuthOptions, AuthOptions>();
            services.AddSingleton<IAuthContext, AuthContext>();
            services.AddHostedService<AuthWorker>();
        }
    }
}
