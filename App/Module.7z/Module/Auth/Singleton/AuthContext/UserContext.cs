﻿using Auth.Data;

using Microsoft.Extensions.Logging;

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth
{
    /// <summary>
    /// Область памяти ассоциированая с активным объектом сеанса
    /// </summary>
    public class UserContext
    {
        

        /// <summary>
        /// Unix-time последней операции
        /// </summary>
        private long LastActive;
        private readonly string Token;
        private readonly User User;
        private readonly ConcurrentDictionary<string, object> SessionObjects;
        private readonly ILogger<UserContext> Logger;

        public UserContext()
        {
            throw new NotSupportedException($"Конструктор UserContext() не поддерживается ...");
        }

        public UserContext(string token, User user)
        {
            this.Logger = Factory.GetLogger<UserContext>();
            this.LastActive = DateTimeOffset.Now.ToUnixTimeMilliseconds();
            this.SessionObjects = new ConcurrentDictionary<string, object>();
            this.Token = token;
            this.User = user;
            if (this.Token == null)
                throw new ArgumentNullException("Token");
            if (this.User == null)
                throw new ArgumentNullException("User");
            if (this.User.Account == null)
                throw new ArgumentNullException("User.Account");
            if (this.User.Roles == null)
                throw new ArgumentNullException("User.Roles");
            this.Logger.LogInformation($"Создан новый экземпляр {GetType().GetTypeName()} => {this}"); 
        }

        public override string ToString() => Token;
        public string GetToken() => this.Token;
        public long GetLastActive() => this.LastActive;
        public void SetLastActive(long timems) => this.LastActive = timems;
        public int GetUserID() => this.User.ID;
        public IEnumerable<Role> GetUserRoles() => this.User.Roles.ToList();
        public string GetUserEmail() => this.User.Account.Email;


        public T Get<T>() where T : class
        {
            this.Logger.LogInformation($"Get<{typeof(T).GetTypeName()}>()");
            T result = null;
            try
            {
                if (SessionObjects.ContainsKey(nameof(T)) == false)
                    SessionObjects[nameof(T)] = typeof(T).New();
                result = (T)SessionObjects[nameof(T)];
                if (result == null)
                    throw new Exception("Почему-то возвращается ссылка на null");
            }
            catch (Exception ex)
            {
                this.Logger.LogError($"Get<{typeof(T).GetTypeName()}>() => ", ex);
            }
            return result;
        }

    }
}
