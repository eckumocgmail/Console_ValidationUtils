﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Auth.Singleton
{
    public interface IAuthSingletonModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
}