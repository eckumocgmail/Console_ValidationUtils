﻿ 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Data.RepositoryPattern
{
    public interface IEntityRepository<TEntity> where TEntity: BaseEntity
    {
        public int Post(TEntity data);
        public int Put(TEntity data);
        public int Patch(params TEntity[] dataset);
        public int Delete(int id);
        public IEnumerable<TEntity> Get(int? id);        
    }
}
