﻿using Data;
 

using System.Collections.Generic;
using System.Linq;

namespace Auth.Fasade
{
    public interface IEntitySearch<TEntity> where TEntity: BaseEntity
    {
        public IEnumerable<TEntity> GetPage(int page, int size);
    }
    public class EntitySearch<TEntity>: IEntitySearch<TEntity> where TEntity : BaseEntity
    {
        protected readonly AppDbContext _context;

        public EntitySearch(AppDbContext context)
        {
            _context = context;
        }
        public IEnumerable<TEntity> GetPage(int page, int size)
            => _context.Set<TEntity>().Skip((page - 1) * size).Take(size).ToArray();

       
    }

}
