﻿ 
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Data
{
 
    [Display(Name = "Учетная запись пользователя")]
    [Table("Account", Schema = "Auth")]
    public class Account: BaseEntity
    {

        [Display(Name = "Адрес электронной почты")]
        [DataType(DataType.EmailAddress)]
        [Required(ErrorMessage = "Необходимо ввести адрес электронной почты")]
        public string Email { get; set; } = "eckumoc@gmail.com";

        [Display(Name = "Пароль")]
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Необходимо ввести пароль")]
        public string Password { get; set; } = "";
        
    }
}
