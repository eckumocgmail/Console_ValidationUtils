﻿
namespace Auth.Data
{
    public class Service: NamedObject 
    {
    }
}
