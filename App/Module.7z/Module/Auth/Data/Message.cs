﻿

using System;
using System.Text.Json.Serialization;

namespace Auth.Data
{
    public class Message: BaseEntity
    {
        public Message()
        {
        }

        public Message(string subject, string text, int? fromUserID, int? toUserID, User? fromUser, User? toUser)
        {
            Subject = subject;
            Text = text;
            FromUserID = fromUserID;
            ToUserID = toUserID;
            FromUser = fromUser;
            ToUser = toUser;
        }

        
        public string? Subject { get; set; } = "";
        public string? Text { get; set; } = null;



        
        public DateTime Created { get; set; } = DateTime.Now;

        /// <summary>
        /// Время считывания        
        /// </summary>
        public DateTime? Readed { get; set; } = null;
        

        public virtual int? FromUserID { get; set; } = 1;
        public virtual int? ToUserID { get; set; } = 1;


        [JsonIgnore]
        public virtual User? FromUser  { get; set; }

        [JsonIgnore]
        public virtual User? ToUser  { get; set; }
    }
}
