﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Services.ConnectionManager
{
    internal interface IConnectionManagerModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
    internal class ConnectionManagerModule : IServiceModule, IConnectionManagerModule
    {
        public void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {
            services.AddScoped<IConnectionManager, ConnectionManagerService>();
        }
    }
}
