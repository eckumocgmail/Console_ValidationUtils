﻿using Auth.Data;

using Data;
using Data.RepositoryPattern;

using Microsoft.EntityFrameworkCore;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Services.AuthRepositories
{
    public class AccountRepository : EntityRepository<Auth.Data.Account>, IAccountRepository
    {
        public override DbSet<Auth.Data.Account> GetDbSet( DbContext context) => ((AppDbContext)context).Accounts;
        public AccountRepository(AppDbContext context) : base(context)
        {
        }

        public Account FindByEmail(string Email) => ((AppDbContext)_context).Accounts.Where(account => account.Email.ToUpper() == Email.ToUpper()).FirstOrDefault();
        public Account FindByPhone(string Phone)
        {
            AppDbContext context = ((AppDbContext)_context);
            Person person = context.Persons.FirstOrDefault(p => p.Phone == Phone);
            if (person == null)            
                return null;
            return context.Accounts.Find(context.Users.FirstOrDefault(u => u.PersonID == person.ID).AccountID);
        }
    }
}
