﻿using Auth.Data;

using Data;
using Data.RepositoryPattern;

using Microsoft.EntityFrameworkCore;

namespace Auth.Services.AuthRepositories
{
    public class LoginRepository: EntityRepository<Auth.Data.Login>, ILoginRepository
    {
        public override DbSet<Login> GetDbSet( DbContext context) => ((AppDbContext)context).Logins;
        public LoginRepository(AppDbContext context) : base(context)
        {
        }

        
    }
}