﻿using Auth.Data;

using Data;
using Data.RepositoryPattern;

using Microsoft.EntityFrameworkCore;

using System.Collections.Generic;
using System.Linq;

namespace Auth.Services.AuthRepositories
{
   
    public interface IUserRoleRepository
    {
        public void AddRoleForUser(int userId, int roleId);
    }
    public class UserRoleRepository : EntityRepository<Auth.Data.UserRole>, IUserRoleRepository
    {
        public override DbSet<Auth.Data.UserRole> GetDbSet( DbContext context) => ((AppDbContext)_context).UserRoles;
        public UserRoleRepository(AppDbContext context) : base(context)
        {
        }
        public void AddRoleForUser(int userId, int roleId)
        {

            ((AppDbContext)_context).UserRoles.Add(new UserRole() { 
                UserID = userId,
                RoleID = roleId
            });
            _context.SaveChanges();
        }

    }
}
