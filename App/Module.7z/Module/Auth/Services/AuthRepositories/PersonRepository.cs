﻿using Auth.Data;

using Data;
using Data.RepositoryPattern;

using Microsoft.EntityFrameworkCore;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Services.AuthRepositories
{
    public class PersonRepository: EntityRepository<Auth.Data.Person>, IPersonRepository
    {
        public override DbSet<Person> GetDbSet(DbContext context) => ((AppDbContext)context).Persons;
        public PersonRepository(AppDbContext context) : base(context)
        {
        }

        
    }

    
}
