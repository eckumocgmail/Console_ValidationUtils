﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Auth.Services.AuthRepositories
{
    public interface IAuthRepositoriesModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
}