﻿using Auth.Data;
using Data;
using Data.RepositoryPattern;
using Microsoft.EntityFrameworkCore;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Auth.Services.AuthRepositories
{
    public interface IRoleRepository: IEntityRepository<Role>
    {
        public ICollection<Role> ForUser(int userId);
    }

    public class RoleRepository : EntityRepository<Auth.Data.Role>, IRoleRepository
    {
        public override DbSet<Auth.Data.Role> GetDbSet(DbContext context) => ((AppDbContext)context).Roles;
        public RoleRepository(AppDbContext context) : base(context)
        {
        }

        public Account FindByEmail(string Email) => ((AppDbContext)_context).Accounts.Where(account => account.Email.ToUpper() == Email.ToUpper()).FirstOrDefault();


        public ICollection<Role> ForUser(int userId)
        {
            var user = ((AppDbContext)_context).Users.Include(user => user.UserRoles).FirstOrDefault(u => u.ID == userId);
            var rids = user.UserRoles.Select(ur => ur.ID);
            return GetDbSet(_context).Where(r => rids.Contains(r.ID)).ToList();
        }
    }
}