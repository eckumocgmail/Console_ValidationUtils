﻿using Auth.Data;

using Data;
using Data.RepositoryPattern;

using Microsoft.EntityFrameworkCore;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Services.AuthRepositories
{
    public class UserRepository: EntityRepository<Auth.Data.User>,IUserRepository
    {
        public override DbSet<User> GetDbSet( DbContext context) => ((AppDbContext)context).Users;
        public UserRepository(AppDbContext context) : base(context)
        {
        }

        public User FindByEmail(string Email)
        {
            var account = ((AppDbContext)_context).Accounts.Where(account => account.Email.ToUpper() == Email.ToUpper()).FirstOrDefault();
            if (account == null)
            {
                return null;
            }
            else
            {
                var user = ((AppDbContext)_context).Users
                    .Include(u=>u.Person)
                    .Include(u=>u.Account)
                    .Where(u=>u.Account.ID==account.ID)
                    .FirstOrDefault();
                if (user == null)
                    throw new Exception($"Нарушение целостности данных каждой записи {nameof(Account)} должна соответсвовать запись {nameof(User)}");
            
                return user;
            }
        }

        public User FindByPhone(string Phone)
        {
             
            AppDbContext context = ((AppDbContext)_context);
            Person person = context.Persons.FirstOrDefault(p => p.Phone == Phone);
            if (person == null)
                return null;
            return context.Users
                .Include(u => u.Person)
                      .Include(u => u.Account).FirstOrDefault(u => u.PersonID == person.ID);      
        }
    }
}
