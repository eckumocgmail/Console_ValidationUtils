﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Services.UserManager
{
    public interface IUserManagerModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
    public class UserManagerModule : IServiceModule, IUserManagerModule
    {
        private ILogger<UserManagerModule> Logger = Factory.GetLogger<UserManagerModule>();

        public void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {
            Logger.LogInformation($"ConfigureServices()");
            services.AddScoped<IUserManager, UserManager>();
        }
    }
}
