﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Auth.Services.AuthCertificate
{
    internal interface IAuthCertificateModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
}