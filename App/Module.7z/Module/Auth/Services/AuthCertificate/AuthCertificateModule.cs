﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Services.AuthCertificate
{
    internal class AuthCertificateModule : IServiceModule, IAuthCertificateModule
    {
        private ILogger<AuthCertificateModule> Logger = Factory.GetLogger<AuthCertificateModule>();

        public void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {
            Logger.LogInformation($"ConfigureServices(...)");
            services.AddScoped<IAuthCretificate, AuthCretificateService>();
        }
    }
}
