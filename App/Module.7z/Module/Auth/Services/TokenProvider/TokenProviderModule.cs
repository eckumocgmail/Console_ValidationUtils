﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using UserAuthMVC.Auth.Services;
using UserAuthMVC.Auth.Services.TokenProvider;

namespace Auth.Services.TokenProvider
{
    internal class TokenProviderModule : IServiceModule, ITokenProviderModule
    {
        private ILogger<TokenProviderModule> Logger = Factory.GetLogger<TokenProviderModule>();
        public void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {
            Logger.LogInformation($"ConfigureServices()");
            if (services.Where(desc => desc.ServiceType.Name == nameof(IHttpContextAccessor)).Count() == 0)
            {
                services.AddHttpContextAccessor();
            }
            services.AddScoped<ITokenProvider, CookieTokenProvider>();
        }
    }
}
