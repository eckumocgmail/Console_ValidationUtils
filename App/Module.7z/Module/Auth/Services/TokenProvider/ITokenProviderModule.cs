﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Auth.Services.TokenProvider
{
    internal interface ITokenProviderModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
}