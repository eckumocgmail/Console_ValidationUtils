﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Auth.Services
{
    public interface IAuthServicesModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
}