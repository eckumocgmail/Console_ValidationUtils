﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Services.SigninManager
{
    internal interface ISigninManagerModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
    internal class SigninManagerModule : IServiceModule, ISigninManagerModule
    {
        private ILogger<SigninManagerModule> Logger = Factory.GetLogger<SigninManagerModule>();
        public void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {
            Logger.LogInformation($"ConfigureServices(...)");     
            services.AddScoped<ISigninManager, SigninManager>();
        }
    }
}
