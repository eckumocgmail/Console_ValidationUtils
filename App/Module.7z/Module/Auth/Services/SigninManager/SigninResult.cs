﻿namespace Auth.Services.SigninManager
{
    public class SigninResult<T> : MethodResult<T> where T : class
    {
        public bool RequiresTwoFactor { get; set; }
        public bool IsLockedOut { get; set; }
        public SigninResult(T result)
        {
            Result = result;
        }
    }
}