﻿using Auth.Data;
using Auth.Services.AuthCertificate;
using Auth.Services.UserManager;

using Microsoft.AspNetCore.Authentication;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using UserAuthMVC.Auth.Services;

namespace Auth.Services.SigninManager
{

    public interface ISigninManager
    {
        public UserContext Signin(User user);
        public bool IsSignIn();
        public int GetUserID();
        public string GetUserEmail();

        public UserContext GetUserContext();

        bool Signout();
        bool IsUserInRole(string area);
        Task<IEnumerable<AuthenticationScheme>> GetExternalAuthenticationSchemesAsync();
        Task<SigninResult<UserContext>> PasswordSignInAsync(string email, string password, bool rememberMe, bool lockoutOnFailure);
        Task SignInAsync(Account user, bool isPersistent);
    }
    public class SigninManager: ISigninManager
    {
        private readonly ITokenProvider _tokenProvider;
        private readonly IAuthContext _authContext;
        private readonly IUserManager _userManager;
        
        public SigninManager(ITokenProvider tokenProvider, IAuthContext authContext, IUserManager userManager)
        {
            _tokenProvider = tokenProvider;
            _authContext = authContext;
            _userManager = userManager;


        }

        public bool IsSignIn()
        {
            string token = _tokenProvider.Get();
            return _authContext.IsSignIn(token);
        }

        public int GetUserID()
        {
            string token = _tokenProvider.Get();
            return _authContext.GetUserID(token);
        }

        public UserContext Signin(User user)
        {
            
            var userContext = _authContext.Signin(user);
            _tokenProvider.Set(userContext.GetToken());
            return userContext;
        }
       

        public bool Signout()
        {
            string token = _tokenProvider.Get();
            _tokenProvider.Set("");
            return _authContext.Signout(token);
        }

        public UserContext GetUserContext()
        {
            return _authContext.GetUserContext(_tokenProvider.Get());
        }

        public bool IsUserInRole(string area)
        {
            if(IsSignIn() == false)
            {
                return false;
            }
            else
            {
                var token = _tokenProvider.Get();
                var context = _authContext.GetUserContext(token);
                return context.GetUserRoles().Where(role => role.Code.ToLower().Equals(area)).Any();
            }
            
        }

        public string GetUserEmail()
        {
            var token = _tokenProvider.Get();

            return _authContext.GetUserContext(token).GetUserEmail();
        }

       

        public async Task<SigninResult<UserContext>> PasswordSignInAsync(string email, string password, bool rememberMe, bool lockoutOnFailure)
        {            
            await Task.CompletedTask;
            User user = _userManager.FindByEmail(email);          
            user = user == null ? _userManager.FindByPhone(email) : user;
            if (user != null)
            {                
                return new SigninResult<UserContext>(Signin(user));
            }
            else
            {
                return null;
            }          
        }

        public async Task<IEnumerable<AuthenticationScheme>> GetExternalAuthenticationSchemesAsync()
        {
            await Task.CompletedTask;
            return new List<AuthenticationScheme>();
        }

        public Task SignInAsync(Account user, bool isPersistent)
        {
            throw new NotImplementedException();
        }
 
    }
}
