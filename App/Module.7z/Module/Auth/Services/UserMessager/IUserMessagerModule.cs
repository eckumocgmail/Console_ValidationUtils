﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Auth.Services.UserMessager
{
    public interface IUserMessagerModule
    {
        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
}