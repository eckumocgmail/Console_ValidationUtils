﻿using Auth.Data;

using Data;
using Data.RepositoryPattern;

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Auth.Services.UserMessager
{


    public interface IUserMessager
    {
        /// <summary>
        /// Устанавливает маркер прочтения письма 
        /// Readed
        /// </summary>
        /// <param name="messageId"></param>
        /// <returns></returns>
        public void ReadMessage(int messageId);
        public IEnumerable<Message> GetNews(int userId);
        public IEnumerable<Message> GetInbox(int userId);
        public IEnumerable<Message> GetOutbox(int userId);
        public void SendMessage(int fromUserId, int toUserId, Message message);
    }




    public class UserMessager: EntityRepository<Message>, IUserMessager
    {
        public UserMessager( AppDbContext context) : base(context)
        {
        }

        public IEnumerable<Message> GetInbox(int userId)
            => ((AppDbContext)_context).Messages.Where(m => m.ToUserID == userId).ToArray();

        public IEnumerable<Message> GetOutbox(int userId)
            => ((AppDbContext)_context).Messages.Where(m => m.FromUserID == userId).ToArray();

        public void SendMessage(int fromUserId, int toUserId, Message message)
        {
            message.FromUserID = fromUserId;
            message.ToUserID = toUserId;
            Post(message);
        }

        public override DbSet<Message> GetDbSet(  DbContext context)
            => ((AppDbContext)context).Messages;

        public IEnumerable<Message> GetNews(int userId)
        {
             return ((AppDbContext)_context).Messages.Where(m => m.ToUserID == userId && m.Readed == null).ToArray();
        }

        public void ReadMessage(int messageId)
        {
            ((AppDbContext)_context).Messages.Find(messageId).Readed = DateTime.Now;
            _context.SaveChanges();
        }
    }
}
