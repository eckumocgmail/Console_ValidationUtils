﻿using Auth.Services.AuthCertificate;
using Auth.Services.AuthRepositories;
using Auth.Services.ConnectionManager;
using Auth.Services.SigninManager;
using Auth.Services.TokenProvider;
using Auth.Services.UserManager;
using Auth.Services.UserMessager;

using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Services
{
    public class AuthServicesModule : IServiceModule, IAuthServicesModule
    {
        private ILogger<SigninManagerModule> Logger = Factory.GetLogger<SigninManagerModule>();

        private IAuthCertificateModule AuthCertificateModule = new AuthCertificateModule();
        private ITokenProviderModule TokenProviderModule = new TokenProviderModule();
        private IAuthRepositoriesModule AuthRepositoriesModule = new AuthRepositoriesModule();
        private ISigninManagerModule SigninManagerModule = new SigninManagerModule();
        private IUserManagerModule UserManagerModule = new UserManagerModule();
        private IConnectionManagerModule ConnectionManagerModule = new ConnectionManagerModule();
        private IUserMessagerModule UserMessagerModule = new UserMessagerModule();
        public void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {
            Logger.LogInformation($"ConfigureServices(...)");
 
            UserMessagerModule.ConfigureServices(configuration, services);
            AuthCertificateModule.ConfigureServices(configuration, services);
            TokenProviderModule.ConfigureServices(configuration, services);
            AuthRepositoriesModule.ConfigureServices(configuration, services);
            SigninManagerModule.ConfigureServices(configuration, services);
            UserManagerModule.ConfigureServices(configuration, services);
            ConnectionManagerModule.ConfigureServices(configuration, services);
        }

       
    }
}
