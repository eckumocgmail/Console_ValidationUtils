﻿using Auth.Services;
using Auth.Singleton;

using Data;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
 

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

 

namespace Auth
{
    public class AuthServiceModule : IServiceModule, IAuthServiceModule
    {
        private ILogger<AuthServiceModule> Logger = Factory.GetLogger<AuthServiceModule>();
        
        public IAuthServicesModule AuthServicesModule { get; set; } = new AuthServicesModule();
        public IDataServiceModule DataServiceModule { get; set; } = new DataServiceModule();
        public IAuthSingletonModule AuthSingletonModule { get; set; } = new AuthSingletonModule();

 
        public void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {
            Logger.LogInformation($"ConfigureServices(...)");
            DataServiceModule.ConfigureServices(configuration, services);
            AuthSingletonModule.ConfigureServices(configuration, services);
            AuthServicesModule.ConfigureServices(configuration, services);
        } 

    }
}

