﻿using Auth.Services;
using Auth.Singleton;

using Data;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Auth
{
    public interface IAuthServiceModule
    {
  

        void ConfigureServices(IConfiguration configuration, IServiceCollection services);
    }
}