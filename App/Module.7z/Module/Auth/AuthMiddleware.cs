﻿using System.Linq;
using System.Threading.Tasks;

using Auth;
using Auth.Services.SigninManager;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.DependencyInjection;

using static System.Console;
using static Newtonsoft.Json.JsonConvert;
 
 
using Microsoft.Extensions.Logging;

using System;
using Auth.Services.TokenProvider;

/// <summary>
/// Компонент промежуточного ПО выполняет ограничение доступа пользователей на уровне маршрутов
/// по результатам проверки авторизации и принадлежности пользователя к той или иной роли.
/// Сущность РОЛЬ имеет иерархическую структуру права доступа наследуются от родительской роли к потомку
/// </summary>
public class AuthMiddleware: IMiddleware
{
    private readonly IAuthContext _context;
    private readonly IAuthOptions authOptions;


    /// <summary>
    /// Конструктор
    /// </summary>
    /// <param name="console">консоль</param>
    /// <param name="context">контекст</param>
    public AuthMiddleware(IAuthOptions options, IAuthContext context)
    {
        _context = context;
        authOptions = options;
    }
    public string GetToken(HttpContext http)
    {
        if (http == null || http.Request == null)
        {
            return null;
        }
        return http.Request.Cookies.ContainsKey("Authorization") == false ? null :
               http.Request.Cookies["Authorization"].ToString();
    }
    public Task InvokeAsync(HttpContext http, RequestDelegate _next)
    {
        
        string url = http.Request.Path.ToString();
        if (url.Length == 0)
        {
            return _next.Invoke(http);
        }
        else
        {
            var ids = url.Substring(1).Split("/");
            if(ids.Length > 2)
            {
            
                string area = ids[0];
                switch (area)
                {
                    case "User":
                        if (_context.IsSignIn(GetToken(http)) == false)
                        {
                            WriteLine(authOptions.LoginPath);
                            http.Response.Redirect(authOptions.LoginPath);
                            
                        }                    
                        break;
                    default:
                        if (_context.IsUserInRole(GetToken(http),area) == false)
                        {
                            WriteLine(authOptions.LoginPath);
                            http.Response.Redirect(authOptions.LoginPath);
                        }                      
                        break;
                }
                
            }                                    
        }
        return _next.Invoke(http);
    }

    private void WriteError(HttpContext http, Exception ex)
    {
        http.Response.ContentType = "text/html;charset=utf-8";
        http.Response.StatusCode = 500;
        http.Response.WriteAsync("<div class='alert alert-error'>" + ex.Message + "</div>");
        http.Response.WriteAsync("<div class='alert alert-warning'>" + ex.StackTrace + "</div>");
    }
 
}

 
 

 