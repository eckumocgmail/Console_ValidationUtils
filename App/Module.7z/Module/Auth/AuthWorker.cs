﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
 

using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Auth
{


    /// <summary>
    /// Периодически выполняет актулизацию сведений о сеансах пользователей
    /// </summary>
    public class AuthWorker: BackgroundService
    {
        private readonly IAuthContext _context;
        private readonly ILogger<AuthWorker> _logger;
        private readonly IAuthOptions _options;


        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="console">консоль</param>
        /// <param name="context">контекст</param>
        public AuthWorker( ILogger<AuthWorker> logger, IAuthOptions options, IAuthContext context )
        {
            _context = context;
            _logger = logger;
            _options = options!=null?options:new AuthOptions();
        }



        /// <summary>
        /// Собственно сама проверка
        /// </summary>
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                //_logger.LogInformation("OnValidate(...)");
                _context.Validate();
                await Task.Delay(_options.ValidationTimeout, stoppingToken);
            }
        }
    }
}
