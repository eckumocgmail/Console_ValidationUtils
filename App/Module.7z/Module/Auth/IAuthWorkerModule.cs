﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

public interface IAuthWorkerModule
{
    void ConfigureServices(IConfiguration configuration, IServiceCollection services);
}