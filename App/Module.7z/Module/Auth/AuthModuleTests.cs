﻿using Auth.Services.SigninManager;

using Microsoft.AspNetCore.Mvc;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class AuthModuleTests: TestingElement
{
    public override void OnTest()
    {  
    }

    public void canUserLogout([FromServices]ISigninManager signin)
    {
        try
        {
             
        }
        catch (Exception ex)
        {

        }
    }

    public void canUserLogin()
    {
        throw new NotImplementedException();
    }

    public void canRegistrateAccount()
    {
        throw new NotImplementedException();
    }
}