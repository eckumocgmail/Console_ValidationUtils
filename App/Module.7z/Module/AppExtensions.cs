﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversalShare;
using UniversalShare.ShareApp;

public static class AppExtensions
{
    public static void AddServiceWorker<TServiceModule>(this IHostBuilder hostBuilder) where TServiceModule : WorkerModule
    {
        var logger = LoggerFactory.Create(options => options.AddConsole()).CreateLogger(nameof(AppExtensions));
        hostBuilder.ConfigureServices((context, services) => {

            logger.LogInformation(typeof(TServiceModule).FullName);
            TServiceModule module = (TServiceModule)typeof(TServiceModule).GetConstructors().First().Invoke(new object[0]);
            module.ConfigureServices(context.Configuration, services);
        });
    }
}